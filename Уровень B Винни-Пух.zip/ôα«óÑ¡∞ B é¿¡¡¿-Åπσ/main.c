#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ENTRIES 100

// Структура для хранения информации о книгах и читателях из первого файла
typedef struct {
    int id;
    char date[20];
    char reader[50];
    int book_id; // Добавляем id книги
} BookReaderInfo;

// Структура для хранения информации о книгах и авторах из второго файла
typedef struct {
    int id;
    char title[100];
    char author[50];
    int author_id; 
} BookAuthorInfo;


// Структура для хранения информации о книгах Пушкина
typedef struct {
    char reader[50]; // Имя читателя
    char title[100]; // Название книги
} PushkinBook;

// Прототип функции для печати списка книг Пушкина
void print_out(PushkinBook v[], int n);

int main() {
    BookReaderInfo reader_info[MAX_ENTRIES]; // Массив структур для хранения информации о читателях и книгах из первого файла
    BookAuthorInfo author_info[MAX_ENTRIES]; // Массив структур для хранения информации о книгах и авторах из второго файла
    int num_reader_info = 0; // Количество записей о читателях и книгах из первого файла
    int num_author_info = 0; // Количество записей о книгах и авторах из второго файла

    // Открытие первого файла для чтения
    FILE *file_1 = fopen("in_1.txt", "r");
    if (file_1 == NULL) {
        printf("Ошибка при открытии файла in_1.txt.\n");
        return 1;
    }

    // Считываем данные из первого файла
    int id_1, book_id; // Добавляем переменную для id книги
    char date[20], reader[50];
    while (fscanf(file_1, "%d;%[^;];%[^;];%d\n", &id_1, date, reader, &book_id) == 4) {
        reader_info[num_reader_info].id = id_1;
        strcpy(reader_info[num_reader_info].date, date);
        strcpy(reader_info[num_reader_info].reader, reader);
        reader_info[num_reader_info].book_id = book_id; // Сохраняем id книги
        num_reader_info++;
    }

    // Закрытие первого файла
    fclose(file_1);

    // Открытие второго файла для чтения
    FILE *file_2 = fopen("in_2.txt", "r");
    if (file_2 == NULL) {
        printf("Ошибка при открытии файла in_2.txt.\n");
        return 1;
    }

    // Считываем данные из второго файла
    int id_2, author_id; // Добавляем переменную для id книги
    char title[20], author[50];
    while (fscanf(file_2, "%d;%[^;];%[^;];%d\n", &id_2, title, author, &author_id) == 4) {
        author_info[num_author_info].id = id_2;
        strcpy(author_info[num_author_info].title, title);
        strcpy(author_info[num_author_info].author, author);
        author_info[num_author_info].author_id = author_id;
        num_author_info++;
    }

    // Закрытие второго файла
    fclose(file_2);

    // Объединяем данные из обоих файлов по id книги
    PushkinBook books[MAX_ENTRIES]; // Массив структур для хранения информации о книгах Пушкина
    int num_books = 0; // Количество книг Пушкина
    for (int i = 0; i < num_reader_info; i++) {
        for (int j = 0; j < num_author_info; j++) {
            if (reader_info[i].book_id == author_info[j].id && strcmp(author_info[j].author, "Александр Пушкин") == 0) {
                strcpy(books[num_books].reader, reader_info[i].reader);
                strcpy(books[num_books].title, author_info[j].title);
                num_books++;
            }
        }
    }

    // Вывод списка книг Пушкина в консоль и запись в файл
    printf("Читатель\tКнига\n");
    print_out(books, num_books);

    return 0;
}
// Функция для печати списка книг Пушкина в файл
void print_out(PushkinBook v[], int n) {
    // Открытие файла для записи
    FILE *out = fopen("out.txt", "w");
    if (out == NULL) {
        printf("Ошибка при создании файла out.txt.\n");
        exit(1);
    }
    // Запись заголовка в файл
    fprintf(out, "Читатель\tКнига\n");
    // Печать информации о книгах Пушкина в файл и в консоль
    for (int i = 0; i < n; i++) {
        fprintf(out, "%s\t%s\n", v[i].reader, v[i].title); // Запись в файл
        printf("%s\t%s\n", v[i].reader, v[i].title); // Вывод в консоль
    }
    // Закрытие файла
    fclose(out);
}

