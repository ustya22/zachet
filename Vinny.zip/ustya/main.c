#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Vinny.h"
#define MAX_ENTRIES 100
int main() {
    Pushkin_LermontovBook books[MAX_ENTRIES]; // Массив структур для хранения информации о книгах Пушкина или Лермонтова
    int num_books = 0; // Количество книг Пушкина и Лермонтова

    // Открытие файла для чтения
    FILE *file = fopen("in.txt", "r");
    if (file == NULL) {
        printf("Ошибка при открытии файла.\n");
        return 1;
    }

    // Чтение данных из файла
    char line[256];
    while (fgets(line, sizeof(line), file)) {
        char date[20], reader[50], title[100], author[50];
        sscanf(line, "%[^;];%[^;];%[^;];%s", date, reader, title, author);

        // Проверка, является ли автор Пушкиным
        if ((strcmp(author, "Пушкин") == 0) || (strcmp(author, "Лермонтов") == 0)){
            strcpy(books[num_books].reader, reader); // Сохранение имени читателя
            strcpy(books[num_books].title, title); // Сохранение названия книги
            num_books++; // Увеличение счетчика книг Пушкина или Лермонтова
        }
    }

    // Закрытие файла
    fclose(file);

    // Вывод списка книг Пушкина в консоль и запись в файл
    printf("Читатель\tКнига\n");
    print_out(books, num_books);

    return 0;
}
