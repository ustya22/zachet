#ifndef __VINNY__
#define __VINNY__
typedef struct {
	char reader[50];
	char title[100];
}Pushkin_LermontovBook;

void print_out(Pushkin_LermontovBook v[], int n);
#endif

