#include <stdio.h>
#include "Vinny.h"
#include <stdlib.h>
#include <string.h>
void print_out(Pushkin_LermontovBook v[], int n) {
    // Открытие файла для записи
    FILE *out = fopen("out.txt", "w");
    if (out == NULL) {
        printf("Ошибка при создании файла.\n");
        exit(1);
    }
    // Запись заголовка в файл
    fprintf(out, "Читатель\tКнига\n");
    // Печать информации о книгах Пушкина или Лермонтова в файл и в консоль
    for (int i = 0; i < n; i++) {
        fprintf(out, "%s\t%s\n", v[i].reader, v[i].title); // Запись в файл
        printf("%s\t%s\n", v[i].reader, v[i].title); // Вывод в консоль
    }
    // Закрытие файла
    fclose(out);
}
